package org.geospeed.ogc.api.wcs;

import org.geospeed.ogc.api.IOgcRequest;


public interface IOgcWcsRequest extends IOgcRequest
{

}
