package org.geospeed.ogc.api.wfs;


public interface IOgcWfsGetCapabilitiesRequest extends IOgcWfsRequest
{
    
}
