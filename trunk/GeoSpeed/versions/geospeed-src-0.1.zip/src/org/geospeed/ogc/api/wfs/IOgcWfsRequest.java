package org.geospeed.ogc.api.wfs;

import org.geospeed.ogc.api.IOgcRequest;


public interface IOgcWfsRequest extends IOgcRequest
{

}
